package G42_Reto3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class G37_Reto3_OkApplicationTests {

	@Test
	void contextLoads() {
	}

}
